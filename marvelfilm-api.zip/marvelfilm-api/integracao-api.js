// Adicione esta linha para criar a lista de filmes quando a página carrega
window.onload = carregarFilmes;

// Função para carregar a lista de filmes e criar botões
async function carregarFilmes() {
    const movieListDiv = document.getElementById('movie-list');

    // Obtenha a lista de filmes da API
    const filmes = await getFilms();

    filmes.forEach(filme => {
        const button = document.createElement('button');
        button.textContent = filme.title;

        // Adicione um ouvinte de evento ao botão
        button.addEventListener('click', () => exibirDetalhes(filme));

        movieListDiv.appendChild(button);
    });
}

// Função para obter a lista de filmes da API
async function getFilms() {
    const response = await fetch('http://localhost:3000/');
    const filmes = await response.json();
    return filmes;
}

// Função para exibir os detalhes do filme
function exibirDetalhes(filme) {
    // Modifique esta parte para atender às suas necessidades
    // Você pode exibir os detalhes do filme em uma janela modal, por exemplo
    alert(`Detalhes do Filme:\nTítulo: ${filme.title}\nDescrição: ${filme.description}\nImagem: ${filme.image_url}\nTrailer: ${filme.trailer_url}`);
}
